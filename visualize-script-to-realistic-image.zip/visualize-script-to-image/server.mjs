import "dotenv/config";
import express from "express";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is not set. Add it to your hosting environment.");
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({ limit: "100kb" }));
app.use(express.static("public"));

const SYSTEM = `You are the visual director for a realistic Indian short-video ad.
Convert a Hindi/Hinglish script into ONE precise image-generation prompt.
The result must be a real photograph, never a cartoon, illustration, 3D render, stick figure,
anime, vector, poster, or diagram.

Infer from the script: subject, approximate age, gender when clear, clothing, emotion,
facial expression, hand gesture, posture, action, environment, time of day and useful props.
If the script does not specify a detail, choose a natural Indian detail that fits the context.
Prefer authentic Indian environments and people who look like ordinary real people, not models.
Use candid smartphone-photography realism: eye-level handheld framing, natural light,
real skin texture, realistic hands, subtle imperfections, moderate contrast, no studio look.
Always compose for a vertical 9:16 social-media frame.

Return ONLY valid JSON with:
{
  "visual_summary": "...",
  "image_prompt": "..."
}
The image_prompt must be self-contained and ready for an image-generation model.`;

app.post("/api/generate-image", async (req, res) => {
  try {
    const { script, characterDetails = "", aspectRatio = "9:16" } = req.body || {};

    if (!script || typeof script !== "string" || script.trim().length < 3) {
      return res.status(400).json({ error: "Please enter a script." });
    }
    if (script.length > 12000) {
      return res.status(400).json({ error: "Script is too long. Keep it under 12,000 characters." });
    }

    const planning = await client.responses.create({
      model: "gpt-5.6-luna",
      instructions: SYSTEM,
      input: `SCRIPT:
${script}

OPTIONAL CHARACTER DETAILS:
${characterDetails || "None. Infer naturally from the script."}

ASPECT RATIO:
${aspectRatio}`,
    });

    let plan;
    try {
      plan = JSON.parse(planning.output_text);
    } catch {
      return res.status(502).json({ error: "The visual-planning response was not valid JSON. Please try again." });
    }

    const imagePrompt = `${plan.image_prompt}

Hard constraints:
- Vertical social-media composition, 9:16.
- Photorealistic real Indian person/people.
- Natural anatomy and realistic hands/fingers.
- Natural facial expression and believable body language.
- No text, captions, logos, watermarks, UI, borders, or graphic design.
- No stick figures, cartoons, illustrations, anime, CGI, 3D render, or plastic skin.
- Make the scene look like it was casually captured on a modern smartphone.`;

    const imageResponse = await client.responses.create({
      model: "gpt-5.6-luna",
      input: imagePrompt,
      tools: [{
        type: "image_generation",
        size: "1024x1536",
        quality: "high",
        output_format: "png"
      }]
    });

    const imageCall = imageResponse.output?.find(x => x.type === "image_generation_call");
    if (!imageCall?.result) {
      return res.status(502).json({ error: "Image generation did not return an image. Please try again." });
    }

    res.json({
      image: `data:image/png;base64,${imageCall.result}`,
      visualSummary: plan.visual_summary,
      prompt: imagePrompt
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      error: err?.message || "Something went wrong while generating the image."
    });
  }
});

app.listen(port, () => {
  console.log(`Visualize running at http://localhost:${port}`);
});