# Visualize — Script → Realistic Character Image

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Put your OpenAI API key in `.env` as `OPENAI_API_KEY=...`.
4. Run:
   npm install
   npm start
5. Open http://localhost:3000

## Deploy
Deploy this Node/Express project to a Node-compatible host (for example Render, Railway, or a VPS).
Set `OPENAI_API_KEY` as a server-side environment variable in the host dashboard.
Do NOT put the key in `public/index.html` or browser JavaScript.

The app uses the OpenAI Responses API with an image-generation tool and a server-side text-planning step.
